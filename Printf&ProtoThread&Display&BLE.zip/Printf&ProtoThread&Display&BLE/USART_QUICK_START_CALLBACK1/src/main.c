/*
NOMES: Eduardo Capellari Culau
       Nelson Weirich Junior 

DATA: 22/06/2018
*/


#include <asf.h>
#include <stdio.h>
#include <stdlib.h>

//Feito por callback. Logo declarar as fun��es de callback.
void usart_read_callback(struct usart_module *const usart_module);
void usart_write_callback(struct usart_module *const usart_module);

//Configurar.
void configure_usart(void); 
void configure_usart_callbacks(void);

//Declara a instancia do uart.
struct usart_module usart_instance;


#define MAX_RX_BUFFER_LENGTH   1

//Deixa no buffer para depois enviar.
volatile uint8_t rx_buffer[MAX_RX_BUFFER_LENGTH];

//Fun��es de callback.
void usart_read_callback(struct usart_module *const usart_module)
{
	usart_write_buffer_job(&usart_instance, (uint8_t *)rx_buffer, MAX_RX_BUFFER_LENGTH);
}

void usart_write_callback(struct usart_module *const usart_module)
{
	usart_read_buffer_job(&usart_instance, (uint8_t *)rx_buffer, MAX_RX_BUFFER_LENGTH);
}

void configure_usart(void)
{
	//Gerar a config padrao.
	struct usart_config config_usart;
	usart_get_config_defaults(&config_usart);
	
	//Seta os pinos.
	config_usart.baudrate    = 9600;
	config_usart.mux_setting = EDBG_CDC_SERCOM_MUX_SETTING;
	config_usart.pinmux_pad0 = EDBG_CDC_SERCOM_PINMUX_PAD0;
	config_usart.pinmux_pad1 = EDBG_CDC_SERCOM_PINMUX_PAD1;
	config_usart.pinmux_pad2 = EDBG_CDC_SERCOM_PINMUX_PAD2;
	config_usart.pinmux_pad3 = EDBG_CDC_SERCOM_PINMUX_PAD3;
	
	//Seta o printf. Ele vai usar as nossas interruption.
	stdio_serial_init(&usart_instance, EDBG_CDC_MODULE, &config_usart);

    //Habilita.
	usart_enable(&usart_instance);
}

void configure_usart_callbacks(void)
{
    //Setar o callBack
	usart_register_callback(&usart_instance, usart_write_callback, USART_CALLBACK_BUFFER_TRANSMITTED);
	usart_register_callback(&usart_instance, usart_read_callback, USART_CALLBACK_BUFFER_RECEIVED);


    //Habilita o callback.
	usart_enable_callback(&usart_instance, USART_CALLBACK_BUFFER_TRANSMITTED);
	usart_enable_callback(&usart_instance, USART_CALLBACK_BUFFER_RECEIVED);
}

//ProtoThreads
#include "pt_lib/pt.h"

struct timer { int start, interval; };

static int timer_expired(struct timer *t)
{ return (int)(++ t->start >= t->interval); }

static void timer_set(struct timer *t, int interval)
{ t->interval = interval; t->start = 0; }

//Tempo de espera da protothread
#define TIMEOUT 10

//Defini��es do pacote. Tamanho, inicio e fim.
#define VB_M 10
#define STX  0x02
#define ETX  0x03	

//PT que recebe. 
PT_THREAD(protothread_decodifica(struct pt *pt, char dado))
{
  
  static int size = 0;
  static unsigned char chk = 0;
  
  PT_BEGIN(pt);
	//Espera receber o STX;
	PT_WAIT_UNTIL(pt, dado == STX);
		//Iniciou a comunica��o, logo espera o proximo dado.
		printf("Recebeu um STX. Inciou a comunicacao.\n");
		PT_YIELD(pt);
		
		//Reativou a protothread, logo pega o QTD_DADO.
		size = (int) dado;
		
		//Pegar os proximos size dados (mensagem).
		printf("Iniciando a receber a mesnagem.\n	");
		while(size > 0){
			PT_YIELD(pt);  //Rerorna para pegar o proximo dado.
			printf("%c", dado);
			chk ^= dado;   //Faz o checksum;
			size--;
		}
		//Pegou todos os dados, logo tem que pegar o checksum.
		PT_YIELD(pt);
		printf("\nCHK = %d\n", dado);
		
		//Verificar se o chk est� certo.
		if(chk == dado){
			 printf("CheckSum deu certo.\n");
		}else{
			 printf("CheckSum deu errado.\n");
			 //Sai da PT.
			 PT_EXIT(pt);
		}
		
		//Pegou o chk, logo tem que pegar o final (ETX).
		PT_YIELD(pt);
	
		//Verificar se est� certo o ETX.
		if( dado == ETX){
			printf("Fim pacote, ETX recebido.\n");
		}else{
			printf("ERRO: ETX n�o est� correto. Falha ao finalizar a comunicacao.\n");	
		}
		chk = 0; //Reseta o checksum;
  PT_END(pt);
}

int main(void)
{
	//Inicializa
	system_init();

	//Configura
	configure_usart();
	configure_usart_callbacks();

	//Ativa o intr do systema para pegar o usb.
	system_interrupt_enable_global();
	
	//Gasta tempo e Inicial. Tempo para abrir o terminal e poder ver desde o inicio.
	for(int wt = 0; wt<1000000;wt++){}
	printf("START....................\n\n");		
	
	//Vetor com os valores X.
	unsigned char vetor_bytes[VB_M] = {STX, 0x06, 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x01, ETX};
	
	//Cria a pThread. E Inicializa.
    struct pt pt;
	PT_INIT(&pt);
	
	//Fica executado para sempre as protoThreads.
	while(1){
		printf("Inicio do vetor.\n");
		for(int i = 0; i < VB_M; i++){
			protothread_decodifica(&pt, vetor_bytes[i]);
			//Gasta tempo para cada char.
			for(int wt = 0; wt<900000;wt++){}
		}
		printf("Fim do vetor.\n\n");
		//Gasta tempo para cada vetor.
		for(int wt = 0; wt<1500000;wt++){}
	}
	
}

