
#ifndef TIMER-DRIVER_H_
#define TIMER-DRIVER_H_

void init_TC3(int tempo);

void enable_interrupt_time();


#endif /* TIMER-DRIVER_H_ */